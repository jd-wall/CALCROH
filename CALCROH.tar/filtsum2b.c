/* filtsum2b.c - Takes a list of doubles and outputs the sum of them and the total number of doubles.
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
  double a=0., b;
  int c=0;

  while (scanf ("%lf\n", &b) != EOF) {
    a += b;
    ++c;
  }
  printf("%.6e\t%d\n", a, c);
}
