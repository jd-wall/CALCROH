/* Calcroh.c - Estimates genetic lengths of ROHs for an inbred individual

Calcroh g f

g = # of generations since common ancestor (e.g., 6 for offspring of 1st cousins)
f = inbreeding coefficient (e.g., .0625 for offspring of 1st cousins)

Output is a list of genetic lengths of ROHs >= 1cM.  Chromosome genetic lengths were taken from Adam Auton's genetic map available from the BEAGLE website.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main (int argc, char *argv[])
{
  int a, b, c, n, howmany, *geno, flag, g, flag1;
  double ran1(), chrlen[23], f, pos, len, temp, len2;
  unsigned short seedv[3], *pseed;
  FILE *pfseed;

  if (argc != 3) {
    printf("Usage: Calcroh g f\n");
    exit(0);
  }
  g = atoi (argv[1]);
  f = atof (argv[2]);

  pfseed = fopen("seedms","r");
  for(a=0;a<3;a++)
    fscanf(pfseed," %hd",seedv+a);
  fclose( pfseed);
  seed48( seedv );

  chrlen[1] = 2.86279;
  chrlen[2] = 2.6884;
  chrlen[3] = 2.23361;
  chrlen[4] = 2.14688;
  chrlen[5] = 2.04089;
  chrlen[6] = 1.9204;
  chrlen[7] = 1.8722;
  chrlen[8] = 1.68003;
  chrlen[9] = 1.66359;
  chrlen[10] = 1.81141;
  chrlen[11] = 1.58219;
  chrlen[12] = 1.74674;
  chrlen[13] = 1.25706;
  chrlen[14] = 1.20203;
  chrlen[15] = 1.4186;
  chrlen[16] = 1.34038;
  chrlen[17] = 1.28491;
  chrlen[18] = 1.17709;
  chrlen[19] = 1.07734;
  chrlen[20] = 1.08267;
  chrlen[21] = .62202;
  chrlen[22] = .72652;

  for (a=1; a<23; ++a) {
    pos = len = len2 = 0.;
    flag = flag1 = 0;
    while (flag == 0) {
      len = - log (ran1()) / g;
      if ((pos + len) > chrlen[a]) {
	len = chrlen[a] - pos;
	len2 += len;
	flag = 1;
      }
      if (flag1 == 0) { 
	if (ran1() < (pos==0. ? f : f/(1. - pow (0.5, (double) g)))) {
	  flag1 = 1;
	  len2 += len;
	}
      }
      else {
	if (flag==1 ||
	    ran1() > ((f - pow (0.5, (double) g)) / (1. - pow (0.5, (double) g)))) {
	  if (len2 >= 0.01)
	    printf("%lf\n", 100. * len2);
	  flag1 = 0;
	  len2 = 0.;
	}
	else
	  len2 += len;
      }
      pos += len;
    }
  }
  
  
  pfseed = fopen("seedms","w");
  pseed = seed48(seedv);
  fprintf(pfseed,"%d %d %d\n",pseed[0], pseed[1],pseed[2]);
}
